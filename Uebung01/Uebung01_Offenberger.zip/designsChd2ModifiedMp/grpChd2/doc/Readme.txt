Original Design done by Thomas Müller-Wipperfürth was modified:

- Naming of design and testbed
- no more usage of cActivated, cInactivated,...
- Naming of directories
- Adaption of quartus project to reflect these changes
- ...pins.qsf was deleted, because it does not contribute anything but confusion
- All files beautified by emacs

